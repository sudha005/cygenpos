License
=======

.. literalinclude:: ../../LICENSE
